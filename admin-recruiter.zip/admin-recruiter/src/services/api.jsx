// Mock API functions
const api = {
  getRecruiters: async () => {
    return new Promise(resolve => {
      setTimeout(() => {
        resolve([
          {
            id: 1,
            name: 'Công ty ABC Tech',
            email: 'hr@abctech.com',
            phone: '0123456789',
            address: 'Hà Nội',
            description: 'Công ty công nghệ hàng đầu Việt Nam'
          },
          {
            id: 2,
            name: 'Công ty XYZ Solutions',
            email: 'contact@xyz.com',
            phone: '0987654321',
            address: 'TP.HCM',
            description: 'Chuyên về phát triển phần mềm'
          }
        ]);
      }, 500);
    });
  },

  createRecruiter: async (data) => {
    return new Promise(resolve => {
      setTimeout(() => {
        resolve({ ...data, id: Date.now() });
      }, 500);
    });
  },

  updateRecruiter: async (id, data) => {
    return new Promise(resolve => {
      setTimeout(() => {
        resolve({ ...data, id });
      }, 500);
    });
  },

  deleteRecruiter: async (id) => {
    return new Promise(resolve => {
      setTimeout(() => {
        resolve({ success: true });
      }, 500);
    });
  }
};

export default api;