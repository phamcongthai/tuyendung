import React from 'react';
import { MenuIcon } from '../icons';

const Header = ({ sidebarOpen, setSidebarOpen }) => {
  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="flex items-center justify-between px-6 py-4">
        <div className="flex items-center">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="text-gray-600 hover:text-gray-900 lg:hidden"
          >
            <MenuIcon />
          </button>
          <h2 className="ml-4 text-xl font-semibold text-gray-800 lg:ml-0">
            Hệ thống quản lý tuyển dụng CV
          </h2>
        </div>
      </div>
    </header>
  );
};

export default Header;