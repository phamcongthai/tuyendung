import React, { useState, useEffect } from 'react';
import { PlusIcon, EditIcon, DeleteIcon } from '../icons';
import Modal from '../ui/Modal';
import ConfirmDialog from '../ui/ConfirmDialog';
import api from '../../services/api';

const Recruiters = ({ showToast }) => {
  const [recruiters, setRecruiters] = useState([]);
  const [loading, setLoading] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [editingRecruiter, setEditingRecruiter] = useState(null);
  const [confirmDelete, setConfirmDelete] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    description: ''
  });
  const [errors, setErrors] = useState({});

  const loadRecruiters = async () => {
    setLoading(true);
    try {
      const data = await api.getRecruiters();
      setRecruiters(data);
    } catch (error) {
      showToast('Không thể tải dữ liệu nhà tuyển dụng', 'error');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRecruiters();
  }, []);

  const handleAdd = () => {
    setEditingRecruiter(null);
    setFormData({
      name: '',
      email: '',
      phone: '',
      address: '',
      description: ''
    });
    setErrors({});
    setModalVisible(true);
  };

  const handleEdit = (record) => {
    setEditingRecruiter(record);
    setFormData(record);
    setErrors({});
    setModalVisible(true);
  };

  const handleDelete = async (id) => {
    try {
      await api.deleteRecruiter(id);
      setRecruiters(recruiters.filter(r => r.id !== id));
      showToast('Xóa nhà tuyển dụng thành công', 'success');
      setConfirmDelete(null);
    } catch (error) {
      showToast('Không thể xóa nhà tuyển dụng', 'error');
    }
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name.trim()) newErrors.name = 'Vui lòng nhập tên công ty';
    if (!formData.email.trim()) {
      newErrors.email = 'Vui lòng nhập email';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Email không đúng định dạng';
    }
    if (!formData.phone.trim()) newErrors.phone = 'Vui lòng nhập số điện thoại';
    if (!formData.address.trim()) newErrors.address = 'Vui lòng nhập địa chỉ';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setLoading(true);
    try {
      if (editingRecruiter) {
        const updated = await api.updateRecruiter(editingRecruiter.id, formData);
        setRecruiters(recruiters.map(r => r.id === editingRecruiter.id ? updated : r));
        showToast('Cập nhật nhà tuyển dụng thành công', 'success');
      } else {
        const created = await api.createRecruiter(formData);
        setRecruiters([...recruiters, created]);
        showToast('Thêm nhà tuyển dụng thành công', 'success');
      }
      setModalVisible(false);
    } catch (error) {
      showToast('Có lỗi xảy ra', 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Quản lý Nhà tuyển dụng</h2>
        <button
          onClick={handleAdd}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md flex items-center space-x-2 transition-colors"
        >
          <PlusIcon />
          <span>Thêm nhà tuyển dụng</span>
        </button>
      </div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tên công ty</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Số điện thoại</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Địa chỉ</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Mô tả</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Thao tác</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {recruiters.map((recruiter) => (
                <tr key={recruiter.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{recruiter.id}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{recruiter.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{recruiter.email}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{recruiter.phone}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{recruiter.address}</td>
                  <td className="px-6 py-4 text-sm text-gray-900 max-w-xs truncate">{recruiter.description}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    <button
                      onClick={() => handleEdit(recruiter)}
                      className="text-blue-600 hover:text-blue-900 inline-flex items-center"
                    >
                      <EditIcon />
                      <span className="ml-1">Sửa</span>
                    </button>
                    <button
                      onClick={() => setConfirmDelete(recruiter)}
                      className="text-red-600 hover:text-red-900 inline-flex items-center"
                    >
                      <DeleteIcon />
                      <span className="ml-1">Xóa</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          
          {recruiters.length === 0 && (
            <div className="text-center py-8">
              <p className="text-gray-500">Chưa có nhà tuyển dụng nào</p>
            </div>
          )}
        </div>
      )}

      <Modal
        isOpen={modalVisible}
        onClose={() => setModalVisible(false)}
        title={editingRecruiter ? 'Sửa nhà tuyển dụng' : 'Thêm nhà tuyển dụng'}
      >
        <form onSubmit={handleSubmit}>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Tên công ty *</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.name ? 'border-red-500' : 'border-gray-300'}`}
                placeholder="Nhập tên công ty"
              />
              {errors.name && <p className="mt-1 text-xs text-red-600">{errors.name}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email *</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.email ? 'border-red-500' : 'border-gray-300'}`}
                placeholder="Nhập email"
              />
              {errors.email && <p className="mt-1 text-xs text-red-600">{errors.email}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Số điện thoại *</label>
              <input
                type="text"
                value={formData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.phone ? 'border-red-500' : 'border-gray-300'}`}
                placeholder="Nhập số điện thoại"
              />
              {errors.phone && <p className="mt-1 text-xs text-red-600">{errors.phone}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Địa chỉ *</label>
              <input
                type="text"
                value={formData.address}
                onChange={(e) => handleInputChange('address', e.target.value)}
                className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 ${errors.address ? 'border-red-500' : 'border-gray-300'}`}
                placeholder="Nhập địa chỉ"
              />
              {errors.address && <p className="mt-1 text-xs text-red-600">{errors.address}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Mô tả</label>
              <textarea
                value={formData.description}
                onChange={(e) => handleInputChange('description', e.target.value)}
                rows={4}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Nhập mô tả về công ty"
              />
            </div>
          </div>

          <div className="flex justify-end space-x-3 mt-6">
            <button
              type="button"
              onClick={() => setModalVisible(false)}
              className="px-4 py-2 text-gray-700 border border-gray-300 rounded-md hover:bg-gray-50"
            >
              Hủy
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
            >
              {loading ? 'Đang xử lý...' : (editingRecruiter ? 'Cập nhật' : 'Thêm')}
            </button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        isOpen={!!confirmDelete}
        onClose={() => setConfirmDelete(null)}
        onConfirm={() => handleDelete(confirmDelete?.id)}
        title="Xác nhận xóa"
        message={`Bạn có chắc chắn muốn xóa nhà tuyển dụng "${confirmDelete?.name}"?`}
      />
    </div>
  );
};

export default Recruiters;